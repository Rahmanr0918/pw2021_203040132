<?php
/* 
    Rahman Ramadan
    203040132
    Praktikum 13.00
*/
?>
   
   
    <?php for ($i = 1; $i < 4; $i++) : ?>
        <?php for ($j = 1; $j < 4; $j++) : ?>
            <?php echo "Ini perulangan Ke ($i, $j)<br>"; ?>


        <?php endfor; ?>
    <?php endfor; ?>
