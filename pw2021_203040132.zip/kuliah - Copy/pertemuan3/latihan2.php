<?php
/* 
Rahman Ramadan
203040132
https://github.com/Rahmanr0918/pw2021_203040132.git
Pertemuan 3 - 18 Februari 2021
mempelajari Struktur Kendali pengkondisian
*/

?>

<?php
// pengkondisian
// if else 
// if else if else
// ternary
// switch

$x = 20;
if ($x < 20) {
    echo "benar";
} else if ($x == 20) {
    echo "uhuy";
} else {
    echo "salah";
}
