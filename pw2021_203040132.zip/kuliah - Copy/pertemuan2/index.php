<?php
/* 
Rahman Ramadan
203040132
https://github.com/Rahmanr0918/pw2021_203040132.git
Pertemuan 2 - 12 Februari 2021
mempelajari Sintaks PHP
*/

?>

<?php
// Pertemuan 2 - PHP Dasar
// Sintaks PHP

// Standar Output
// echo, print
// print_r
// var_dump

// penulisan sintaks PHP
// 1. php di dalam html
// 2. html di dalam php

// variabel dan tipe data
// variabel
// menggunakan $ 
//  tidak boleh diawali dengan angka, tapi boleh menggunakan angka

// $nama = "Rahman Ramadan";
// $umur = "18";

// echo "halo, nama saya $nama umur saya $umur"



// operator
// aritmatika
// + - * /

// $x = 10;
// $y = 20;
// echo $y +$x;

// penggabung string / concatenation / concat
// .
// $nama_depan = "Rahman";
// $nama_belakang = "Ramadan";
// echo $nama_depan . " " . $nama_belakang


// Assignment
// =, +=, -=, /=, %=, .=
// $x = 1;
// $x += 5;
// echo $x;
// $nama = "rahman";
// $nama .= " ";
// $nama .= "ramadan";
// echo $nama;


// operator perbandingan
// <, >, <=, >=, ==, !=

// var_dump (1 > 5);


// identitas
// === , !==
// var_dump (1 == 1);


// logika
// && , || , !

// $x = 10;
// var_dump($x < 20 || $x % 2 == 0);


?>