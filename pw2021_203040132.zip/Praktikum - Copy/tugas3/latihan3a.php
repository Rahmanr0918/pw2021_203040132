<?php $arrays = ["ada", "abel","men","pung", "nilai"];

echo "Array  $arrays[0]lah suatu vari$arrays[1] yang dapat $arrays[2]am$arrays[3] banyak  $arrays[4]"; ?>



